using UnityEngine;
using System.Collections;

// Makes objects float up & down while gently spinning.
public class FloatMovement : MonoBehaviour {
// User Inputs
public float degreesPerSecond = 15.0f;
public float amplitude = 0.5f;
public float frequency = 1f;

// Position Storage Variables
Vector3 posOffset = new Vector3 ();
Vector3 tempPos = new Vector3 ();

// Use this for initialization
void Start () {
// Store the starting position & rotation of the object
    posOffset = transform.position;
}

// Update is called once per frame
    void Update()
    {
        transform.position = new Vector3(posOffset.x, Mathf.Sin(Time.time * frequency) * amplitude + posOffset.y, 0);
    }
}